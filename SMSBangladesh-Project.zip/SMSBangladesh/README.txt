SMS Bangladesh - Android Studio Project

1. Android Studio খুলুন -> File -> Open -> এই SMSBangladesh ফোল্ডারটি সিলেক্ট করুন
2. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন (ইন্টারনেট লাগবে)
3. Build -> Build Bundle(s)/APK(s) -> Build APK(s)
4. app/build/outputs/apk/debug/app-debug.apk ফোনে ইনস্টল করুন

--- কম্পিউটার ছাড়া (শুধু মোবাইলে) APK বানাতে ---
1. github.com-এ একটি ফ্রি অ্যাকাউন্ট খুলুন, নতুন repository বানান (নাম: sms-bangladesh)
2. এই ফোল্ডারের সব ফাইল (লুকানো .github ফোল্ডারসহ) repository-তে আপলোড করুন (branch: main)
3. Actions ট্যাবে Build APK নিজে থেকে চলবে (৪-৬ মিনিট)
4. Releases সেকশন থেকে SMS-Bangladesh.apk ডাউনলোড করে ইনস্টল করুন
