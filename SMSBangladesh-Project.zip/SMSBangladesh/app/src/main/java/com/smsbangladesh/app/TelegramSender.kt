package com.smsbangladesh.app

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object TelegramSender {

    /** Telegram-এ মেসেজ পাঠায়। ব্যর্থ হলে ৩ বার চেষ্টা করে। */
    fun send(token: String, chatId: String, text: String): Boolean {
        repeat(3) { attempt ->
            try {
                val url = URL("https://api.telegram.org/bot$token/sendMessage")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 15000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")

                val data = "chat_id=" + URLEncoder.encode(chatId, "UTF-8") +
                        "&text=" + URLEncoder.encode(text.take(4000), "UTF-8")
                conn.outputStream.use { it.write(data.toByteArray()) }

                val ok = conn.responseCode == 200
                conn.disconnect()
                if (ok) return true
            } catch (e: Exception) {
                // নেট সমস্যা হলে আবার চেষ্টা
            }
            Thread.sleep(2000L * (attempt + 1))
        }
        return false
    }
}
