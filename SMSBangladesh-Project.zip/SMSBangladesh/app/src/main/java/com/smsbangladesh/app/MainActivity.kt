package com.smsbangladesh.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var etToken: EditText
    private lateinit var etChat: EditText
    private lateinit var swEnable: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val title = TextView(this).apply {
            text = "SMS Bangladesh"
            textSize = 24f
            gravity = Gravity.CENTER
        }

        etToken = EditText(this).apply {
            hint = "Telegram Bot Token"
            setText(prefs.getString("token", ""))
            setSingleLine()
        }
        etChat = EditText(this).apply {
            hint = "Chat ID"
            setText(prefs.getString("chat", ""))
            setSingleLine()
        }
        swEnable = Switch(this).apply {
            text = "Auto Forward চালু"
            isChecked = prefs.getBoolean("enabled", true)
        }

        val btnSave = Button(this).apply { text = "Save" }
        val btnTest = Button(this).apply { text = "Test মেসেজ পাঠান" }
        val btnBattery = Button(this).apply { text = "ব্যাটারি Optimization বন্ধ করুন" }

        btnSave.setOnClickListener {
            prefs.edit()
                .putString("token", etToken.text.toString().trim())
                .putString("chat", etChat.text.toString().trim())
                .putBoolean("enabled", swEnable.isChecked)
                .apply()
            toast("Saved ✅")
            askSmsPermission()
        }

        btnTest.setOnClickListener {
            val t = etToken.text.toString().trim()
            val c = etChat.text.toString().trim()
            Thread {
                val ok = TelegramSender.send(t, c, "✅ SMS Bangladesh: Test সফল!")
                runOnUiThread { toast(if (ok) "পাঠানো হয়েছে ✅" else "ব্যর্থ ❌ Token/Chat ID চেক করুন") }
            }.start()
        }

        btnBattery.setOnClickListener {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:$packageName")))
        }

        listOf(title, etToken, etChat, swEnable, btnSave, btnTest, btnBattery)
            .forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })

        askSmsPermission()
    }

    private fun askSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECEIVE_SMS), 1)
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
